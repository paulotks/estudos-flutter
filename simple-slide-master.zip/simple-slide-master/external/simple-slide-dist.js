import '../css/simple-slide.css';

import SimpleSlide from '../js/simple-slide.js';
window.SimpleSlide = SimpleSlide;